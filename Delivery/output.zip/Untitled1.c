// train.c

#include <stdio.h>
#include <stdlib.h>
#include "Element.h"

Element* ajouterLocomotive(Element* tete, int numero) {
    Element* nouvelleLocomotive = creerElement(numero, LOCOMOTIVE, OK);
    nouvelleLocomotive->suivant = tete;
    return nouvelleLocomotive;
}

Element* ajouterWagon(Element* tete, int numero) {
    Element* nouveauWagon = creerElement(numero, WAGON, OK);
    if (tete == NULL) {
        return nouveauWagon;
    }

    Element* dernier = tete;
    while (dernier->suivant != NULL) {
        dernier = dernier->suivant;
    }

    dernier->suivant = nouveauWagon;
    return tete;
}

Element* rechercherWagon(Element* tete, int numero) {
    Element* courant = tete;
    while (courant != NULL) {
        if (courant->type == WAGON && courant->numero == numero) {
            return courant;
        }
        courant = courant->suivant;
    }
    return NULL;
}

void afficherTrain(Element* tete) {
    Element* courant = tete;
    while (courant != NULL) {
        afficherElement(courant);
        courant = courant->suivant;
    }
}

Element* supprimerWagonPanne(Element* tete) {
    Element* courant = tete;
    Element* precedent = NULL;

    while (courant != NULL) {
        if (courant->type == WAGON && courant->etat == EN_PANNE) {
            if (precedent == NULL) {
                tete = courant->suivant;
            } else {
                precedent->suivant = courant->suivant;
            }
            free(courant);
            return tete;
        }

        precedent = courant;
        courant = courant->suivant;
    }

    return tete;
}

Element* ajouterWagonPosition(Element* tete, int numero, int position) {
    Element* nouveauWagon = creerElement(numero, WAGON, OK);

    if (position == 0) {
        nouveauWagon->suivant = tete;
        return nouveauWagon;
    }

    Element* courant = tete;
    for (int i = 0; i < position - 1 && courant != NULL; i++) {
        courant = courant->suivant;
    }

    if (courant == NULL) {
        // La position est plus grande que la taille de la liste, ajouter � la fin.
        return ajouterWagon(tete, numero);
    }

    nouveauWagon->suivant = courant->suivant;
    courant->suivant = nouveauWagon;
    return tete;
}
